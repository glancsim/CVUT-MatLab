% test_input.m - Test 7: Prostý nosník
%
% Popis: Nosník podepřený na obou koncích, zatížený uprostřed

%% PRŮŘEZY
sections.id = [20];  % section id in sectionsSet.mat

%% UZLY
nodes.x = [0; 2.5; 5; 7.5; 10];      % x coordinates of nodes
nodes.y = [0; 0; 0; 0; 0];           % y coordinates of nodes  
nodes.z = [0; 0; 0; 0; 0];           % z coordinates of nodes

%% DISKRETIZACE
ndisc = 10;  % discretization of beams

%% PODPORY - Kloubové podpory na koncích
kinematic.x.nodes = [];              % node indices with restricted x-direction displacements
kinematic.y.nodes = [1; 5];          % node indices with restricted y-direction displacements
kinematic.z.nodes = [1; 5];          % node indices with restricted z-direction displacements
kinematic.rx.nodes = [];             % node indices with restricted x-direction rotations
kinematic.ry.nodes = [];             % node indices with restricted y-direction rotations
kinematic.rz.nodes = [1; 5];         % node indices with restricted z-direction rotations

%% PRVKY
beams.nodesHead = [1; 2; 3; 4];      % elements starting nodes
beams.nodesEnd = [2; 3; 4; 5];       % elements ending nodes
beams.sections = [1; 1; 1; 1];       % section to beams
beams.angles = [0; 0; 0; 0];         % angle of section

%% ZATÍŽENÍ - Zatížení uprostřed
loads.x.nodes = [];                  % node indices with x-direction forces
loads.x.value = [];                  % magnitude of the x-direction forces

loads.y.nodes = [3];                 % node indices with y-direction forces
loads.y.value = [-15];               % magnitude of the y-direction forces

loads.z.nodes = [];                  % node indices with z-direction forces
loads.z.value = [];                  % magnitude of the z-direction forces

loads.rx.nodes = [];                 % node indices with x-direction moments
loads.rx.value = [];                 % magnitude of the x-direction moments

loads.ry.nodes = [];                 % node indices with y-direction moments
loads.ry.value = [];                 % magnitude of the y-direction moments

loads.rz.nodes = [];                 % node indices with z-direction moments
loads.rz.value = [];                 % magnitude of the z-direction moments
